<footer id="footer">
    <div class="container">
      <div class="copyright">
		<div class="row cf">
			<div class="col-lg-4 col-md-4">
				<div class="social-links">
					<a href="https://www.linkedin.com/company/accountants-network-marketing/" target="_blank" class="linkedin"><i class="fa fa-linkedin"></i></a>
				</div>
			</div>
			
			<div class="col-lg-4 col-md-4">
				&copy; Copyright <strong>ANM Media LLC</strong>. All Rights Reserved
			</div>
			
			<div class="col-lg-4 col-md-4 linkright">
				<a href="privacy-policy.html" >Privacy Policy</a> &nbsp;|&nbsp; <a href="terms-of-service.html" >Terms of service</a>
			</div>
		</div>
      </div>
    </div>
  </footer>
  
  
 <!--Start of Tawk.to Script-->
	<script type="text/javascript">
	var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
	(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
	s1.async=true;
	s1.src='https://embed.tawk.to/5b92afe6f31d0f771d848c0e/default';
	s1.charset='UTF-8';
	s1.setAttribute('crossorigin','*');
	s0.parentNode.insertBefore(s1,s0);
	})();
	</script>
<!--End of Tawk.to Script--> 
  
  
  
  
  
  
  
  
  
  